// modules/chess/chess.js
// version: 4.9.8.860
// Chess → Music is still largely in the shell (deep coupling to MIDI/DB/makeVoice).
// This module marks the feature version and ensures the open path is available.
// Full extract deferred — shell retains chessOverlay / ChessMusic / ChessReplay.
(function(){
  'use strict';
  var MODULE_VERSION = '4.9.8.860';
  window.registerModule('chess', {
    version: MODULE_VERSION,
    isStub: false,
    inShell: true,
    open: function(){
      if(window.ChessMusic && window.ChessMusic.open) window.ChessMusic.open();
    }
  });
  console.log('[modules] chess v' + MODULE_VERSION + ' (logic still in shell)');
})();
